"use client";

import { MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Map from "@/components/Map";

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-primary/90 to-primary/70 text-white">
        <div className="container mx-auto px-4 py-8 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <MapPin className="h-8 w-8" />
            <h1 className="text-3xl font-bold">GeoEduPortal</h1>
          </div>
          <div className="flex gap-4">

          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map Section - Spans 2 columns on large screens */}
          <div className="lg:col-span-2 bg-card p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-semibold mb-4">Mapa Geológico Interactivo</h2>
            <div className="aspect-[16/9] bg-muted rounded-md">
              <Map />
            </div>
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#e63946]"></span>
                <span className="text-sm">Investigación</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#2a9d8f]"></span>
                <span className="text-sm">Minería</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#ee9b00]"></span>
                <span className="text-sm">Volcánico</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-[#457b9d]"></span>
                <span className="text-sm">Otros</span>
              </div>
            </div>
          </div>

          {/* News Section */}
          <div className="bg-card p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-semibold mb-4">Últimas Noticias Geológicas</h2>
            <div className="space-y-4">
              <div className="border-b pb-4">
                <h3 className="font-medium">Exploraciones Geológicas en los Andes</h3>
                <p className="text-sm text-muted-foreground">
                  Nuevos descubrimientos en la cordillera andina revelan importantes formaciones geológicas que datan de la era paleozoica.
                </p>
                <span className="inline-block mt-2 text-xs text-primary">Hace 2 días</span>
              </div>
              <div className="border-b pb-4">
                <h3 className="font-medium">Investigación Minera en Región Sur</h3>
                <p className="text-sm text-muted-foreground">
                  Estudios recientes muestran importantes yacimientos de cobre y litio en la región sur del continente.
                </p>
                <span className="inline-block mt-2 text-xs text-primary">Hace 5 días</span>
              </div>
              <div className="pb-4">
                <h3 className="font-medium">Actividad Volcánica en la Zona Central</h3>
                <p className="text-sm text-muted-foreground">
                  Monitoreo constante revela patrones interesantes en la actividad volcánica de la región central.
                </p>
                <span className="inline-block mt-2 text-xs text-primary">Hace 1 semana</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}